#include "util/flags.h"
#include "util/logger.h"
#include "simulation.h"
#include <cstdlib>
#include <string>

using namespace std;


int main(int argc, char** argv) {
    FlagOptions flags = parse_flags(argc, argv);
    Logger logger(flags.verbose, flags.detailed);

    Simulation simulation(flags.scheduler, logger);

    simulation.run(flags.filename);

    return EXIT_SUCCESS;
}
