#include "algorithms/fcfs.h"
#include <string>

using namespace std;


SchedulingDecision* FcfsScheduler::get_next_thread(const Event* event) {
    SchedulingDecision* decision = new SchedulingDecision;
    decision->thread = fcfsThread.front();

    string s = to_string(size()) + " threads selected. These will run to completion";
    
    decision->explanation = s;
    fcfsThread.pop();
    
    return decision;
}


void FcfsScheduler::enqueue(const Event* event, Thread* thread) {
    fcfsThread.push(thread);
}


bool FcfsScheduler::should_preempt_on_arrival(const Event* event) const {
    return false;
}


size_t FcfsScheduler::size() const {
    return fcfsThread.size();
}
