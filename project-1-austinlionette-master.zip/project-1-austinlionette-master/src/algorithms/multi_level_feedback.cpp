#include "algorithms/multi_level.h"

using namespace std;


SchedulingDecision* MultilevelFeedbackScheduler::get_next_thread(const Event* event) {
    
    SchedulingDecision* decision = new SchedulingDecision;
    
    if(firstQ.size() > 0){
        decision->thread = firstQ.front();
        string s = "From queue number 0";
        decision->explanation = s;
        firstQ.pop();
    }
    else if(secondQ.size() > 0){
        decision->thread = secondQ.front();
        string s = "From queue number 1";
        decision->explanation = s;
        secondQ.pop();
    }
    else if(thirdQ.size() > 0){
        decision->thread = thirdQ.front();
        string s = "From queue number 2";
        decision->explanation = s;
        thirdQ.pop();
    }
    else if(fourthQ.size() > 0){
        decision->thread = fourthQ.front();
        string s = "From queue number 3";
        decision->explanation = s;
        fourthQ.pop();
    }

    return decision;
}


void MultilevelFeedbackScheduler::enqueue(const Event* event, Thread* thread) {
    if(thread->currentQ == "first" || thread->slice == 3){
        thread->currentQ = "first";
        firstQ.push(thread);
        thread->slice = slice0;
        
    }
    else if(thread->currentQ == "second"){
        secondQ.push(thread);
        thread->slice = slice1;
    }
    else if(thread->currentQ == "third"){
        thirdQ.push(thread);
        thread->slice = slice2;
    }
    else if(thread->currentQ == "fourth"){
        fourthQ.push(thread);
        thread->slice = slice3;
    }
}


bool MultilevelFeedbackScheduler::should_preempt_on_arrival(const Event* event) const {
    if((event->thread->bursts.front()->length) > (event->thread->slice)){
        event->thread->bursts.front()->length = (event->thread->bursts.front()->length) - (event->thread->slice);

        if(event->thread->currentQ == "first"){
            event->thread->currentQ = "second";
        }
        else if(event->thread->currentQ == "second"){
            event->thread->currentQ = "third";
        }
        else if(event->thread->currentQ == "third"){
            event->thread->currentQ = "fourth";
        }
        return true;
    }
    else{
        return false;
    }
}


size_t MultilevelFeedbackScheduler::size() const {
    return firstQ.size() + secondQ.size() + thirdQ.size() + fourthQ.size();
}
