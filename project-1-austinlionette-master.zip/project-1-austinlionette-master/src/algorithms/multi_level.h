#pragma once
#include "algorithms/scheduler.h"
#include "types/event.h"
#include "types/scheduling_decision.h"
#include "types/thread.h"


class MultilevelFeedbackScheduler : public Scheduler {
public:

    std::queue<Thread*> firstQ;

    std::queue<Thread*> secondQ;

    std::queue<Thread*> thirdQ;

    std::queue<Thread*> fourthQ;


    SchedulingDecision* get_next_thread(const Event* event){
        override;
    } 


    void enqueue(const Event* event, Thread* thread){
        override;
    } 


    bool should_preempt_on_arrival(const Event* event){
        const override;
    } 


    size_t size() const override;


    size_t slice0 = 1;

    size_t slice1 = 2;

    size_t slice2 = 4;

    size_t slice3 = 8;

private:

};
