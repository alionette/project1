#pragma once
#include "types/event.h"
#include "types/scheduling_decision.h"
#include "types/thread.h"


struct Scheduler {

    SchedulingDecision* get_next_thread(const Event* event) = 0;

    void enqueue(const Event* event, Thread* thread) = 0;

    bool should_preempt_on_arrival(const Event* event) const = 0;

    size_t size() const = 0;

    bool empty() const { 
        return size() == 0; 
    }

    virtual ~Scheduler() {

    }

};
