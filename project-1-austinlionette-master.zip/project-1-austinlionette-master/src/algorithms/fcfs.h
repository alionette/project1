#pragma once
#include "algorithms/scheduler.h"
#include "types/event.h"
#include "types/scheduling_decision.h"
#include "types/thread.h"


class FcfsScheduler : public Scheduler {
public:

    std::queue<Thread*> fcfsThread;

    size_t size() const override;

    SchedulingDecision* get_next_thread(const Event* event){
        override;
    } 

    void enqueue(const Event* event, Thread* thread){
        override;
    } 

    bool should_preempt_on_arrival(const Event* event){
        const override;
    } 

   

private:
    
};
