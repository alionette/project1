#pragma once
#include "algorithms/scheduler.h"
#include "types/event.h"
#include "types/scheduling_decision.h"
#include "types/thread.h"\


class PriorityScheduler : public Scheduler {
public:

    SchedulingDecision* get_next_thread(const Event* event){
        override;
    }


    void enqueue(const Event* event, Thread* thread){
        override;
    } 


    bool should_preempt_on_arrival(const Event* event){
        const override;
    } 


    size_t size() const override;

    std::queue<Thread*> zeroQ;

    std::queue<Thread*> oneQ;

    std::queue<Thread*> twoQ;

    std::queue<Thread*> threeQ;

private:

};
