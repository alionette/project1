#include "algorithms/round_robin.h"
#include <iostream>

using namespace std;


SchedulingDecision* RoundRobinScheduler::get_next_thread(const Event* event) {
    
    SchedulingDecision* decision = new SchedulingDecision;

    if (otherThreads.size() > 0){
        decision->thread = otherThreads.front();
        string s = to_string(otherThreads.size()) + " threads selected. These will run for 3 ticks";
        decision->explanation = s;
        otherThreads.pop();
    }
    else{
        decision->thread = readyThreads.front();
        string s = to_string(readyThreads.size()) + " threads selected. These will run for 3 ticks";
        decision->explanation = s;
        readyThreads.pop();
    }
    
    return decision;
}


void RoundRobinScheduler::enqueue(const Event* event, Thread* thread) {
    thread->slice = timeSlice;

    if(readyThreads.size() > 0 && thread->time_left > 0){
        otherThreads.push(thread);
    }
    else{
        readyThreads.push(thread);
        thread->time_left = 0;
    }
}


bool RoundRobinScheduler::should_preempt_on_arrival(const Event* event) const {
    if(event->thread->bursts.front()->length > timeSlice){
        event->thread->bursts.front()->length = (event->thread->bursts.front()) - timeSlice;
        event->thread->time_left = 0;
        return true;
    }
    return false;
}


size_t RoundRobinScheduler::size() const {
    return readyThreads.size() + otherThreads.size();
}