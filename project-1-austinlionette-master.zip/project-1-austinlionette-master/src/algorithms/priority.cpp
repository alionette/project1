#include "algorithms/priority.h"
#include "types/process.h"

using namespace std;


SchedulingDecision* PriorityScheduler::get_next_thread(const Event* event) {
    
    SchedulingDecision* decision = new SchedulingDecision;
    
    if(zeroQ.size() > 0){
        decision->thread = zeroQ.front();
        string s = "From queue number 0";
        decision->explanation = s;
        zeroQ.pop();
    }
    else if(oneQ.size() > 0){
        decision->thread = oneQ.front();
        string s = "From queue number 1";
        decision->explanation = s;
        oneQ.pop();
    }
    else if(twoQ.size() > 0){
        decision->thread = twoQ.front();
        string s = "From queue number 2";
        decision->explanation = s;
        twoQ.pop();
    }
    else if(threeQ.size() > 0){
        decision->thread = threeQ.front();
        string s = "From queue number 3";
        decision->explanation = s;
        threeQ.pop();
    }

    return decision;
}


void PriorityScheduler::enqueue(const Event* event, Thread* thread) {

    if(thread->process->type == Process::Type::SYSTEM){
        zeroQ.push(thread);
    }
    else if(thread->process->type == Process::Type::INTERACTIVE){
        oneQ.push(thread);
    }
    else if(thread->process->type == Process::Type::NORMAL){
        twoQ.push(thread);
    }
    else{
        threeQ.push(thread);
    }

}


bool PriorityScheduler::should_preempt_on_arrival(const Event* event) const {
    return false;
}


size_t PriorityScheduler::size() const {
    return zeroQ.size() + oneQ.size() + twoQ.size() + threeQ.size();
}
