#include "simulation.h"
#include "types/event.h"
#include <cassert>
#include <fstream>
#include <iostream>
#include <string>
#include <math.h>

using namespace std;

queue<Thread*> running;


void Simulation::run(const string& file) {
    read_file(file);

    // While their are still events to process, invoke the corresponding methods
    // to handle them.
    while (!events.empty()) {
        const Event* event = events.top();
        events.pop();

        // Invoke the appropriate method on the scheduler for the given event type.
        switch (event->type) {
        case Event::THREAD_ARRIVED:
            handle_thread_arrived(event);
            logger.print_state_transition(event, event->thread->previous_state, event->thread->current_state);
            break;

        case Event::THREAD_DISPATCH_COMPLETED:
            handle_thread_dispatch_completed(event);
            logger.print_state_transition(event, event->thread->previous_state, event->thread->current_state);
            break;

        case Event::PROCESS_DISPATCH_COMPLETED:
            handle_process_dispatch_completed(event);
            logger.print_state_transition(event, event->thread->previous_state, event->thread->current_state);
            break;

        case Event::CPU_BURST_COMPLETED:
            handle_cpu_burst_completed(event);
            logger.print_state_transition(event, event->thread->previous_state, event->thread->current_state);
            break;

        case Event::IO_BURST_COMPLETED:
            handle_io_burst_completed(event);
            logger.print_state_transition(event, event->thread->previous_state, event->thread->current_state);
            break;

        case Event::THREAD_COMPLETED:
            handle_thread_completed(event);
            logger.print_state_transition(event, event->thread->previous_state, event->thread->current_state);
            if(events.empty()){
                stats.total_time = event->time;
                for(int i = 0; i<processes.size(); ++i){
                    logger.print_process_details(processes[i]);
                }
                logger.print_statistics(calculate_statistics());
            }
            break;

        case Event::THREAD_PREEMPTED:
            handle_thread_preempted(event);
            logger.print_state_transition(event, event->thread->previous_state, event->thread->current_state);
            break;

        case Event::DISPATCHER_INVOKED:
            handle_dispatcher_invoked(event);
            break;
        }

        // Free the event's memory.
        delete event;
    }
}


//==============================================================================
// Event-handling methods
//==============================================================================


void Simulation::handle_thread_arrived(const Event* event) {
    // TODO: handle this event properly (feel free to modify code structure, tho)
    scheduler->enqueue(event, event->thread);
    event->thread->set_thread_state(Thread::State::READY, event->time, 0);
    Event* newEvent = new Event(Event::DISPATCHER_INVOKED, event->time, event->thread);
    add_event(newEvent);
}


void Simulation::handle_thread_dispatch_completed(const Event* event) {
    // TODO: handle this event properly (feel free to modify code structure, tho)
    if(scheduler->should_preempt_on_arrival(event)){
        int t = 0;
        if(event->thread->time_left == 0){
            t = event->thread->slice;
        }
        else if(event->thread->time_left != 0){
            t = event->thread->time_left;
            event->thread->time_left = 0;
        }
        event->thread->set_thread_state(Thread::State::RUNNING, event->time, t);
        Event* newEvent = new Event(Event::THREAD_PREEMPTED, event->time + t, event->thread);
        add_event(newEvent);
    }

    else{
        if(event->thread->slice < event->thread->bursts.front()->length){
            event->thread->time_left = event->thread->bursts.front()->length - event->thread->slice;
        }
        else if(event->thread->slice > event->thread->bursts.front()->length){
            event->thread->time_left = 0;
        }
        event->thread->set_thread_state(Thread::State::RUNNING, event->time, event->thread->bursts.front()->length);

        prev_thread = active_thread;
        active_thread = event->thread;

        if(event->thread->bursts.size() == 1){
            Event* newEvent = new Event(Event::THREAD_COMPLETED, event->time + event->thread->bursts.front()->length, event->thread);
            add_event(newEvent);
        }
        else{
            Event* newEvent = new Event(Event::CPU_BURST_COMPLETED, event->time + event->thread->bursts.front()->length, event->thread);
            add_event(newEvent);
        }
    }
}


void Simulation::handle_process_dispatch_completed(const Event* event) {
    // TODO: handle this event properly (feel free to modify code structure, tho)
    if(scheduler->should_preempt_on_arrival(event)){
        int t = 0;
        if(event->thread->time_left == 0){
            t = event->thread->slice;
        }
        else if(event->thread->time_left != 0){
            t = event->thread->time_left;
            event->thread->time_left = 0;
        }
        event->thread->set_thread_state(Thread::State::RUNNING, event->time, t);
        prev_thread = active_thread;
        active_thread = event->thread;
        Event* newEvent = new Event(Event::THREAD_PREEMPTED, event->time + t, event->thread);
        add_event(newEvent);
    }

    else{
        if(event->thread->slice < event->thread->bursts.front()->length){
            event->thread->time_left = event->thread->bursts.front()->length - event->thread->slice;
        }
        else if(event->thread->slice > event->thread->bursts.front()->length){
            event->thread->time_left = 0;
        }
        event->thread->set_thread_state(Thread::State::RUNNING, event->time, event->thread->bursts.front()->length);
        prev_thread = active_thread;
        active_thread = event->thread;
        if(event->thread->bursts.size() == 1){
            Event* newEvent = new Event(Event::THREAD_COMPLETED, event->time + event->thread->bursts.front()->length, event->thread);
            add_event(newEvent);
        }
        else if(event->thread->bursts.size() != 1){
            Event* newEvent = new Event(Event::CPU_BURST_COMPLETED, event->time + event->thread->bursts.front()->length, event->thread);
            add_event(newEvent);
        }
    }
}


void Simulation::handle_cpu_burst_completed(const Event* event) {
    // TODO: handle this event properly (feel free to modify code structure, tho)
    event->thread->bursts.pop();

    if(!event->thread->bursts.empty()){
        event->thread->set_thread_state(Thread::State::BLOCKED, event->time, event->thread->bursts.front()->length);
        Event* newEvent = new Event(Event::IO_BURST_COMPLETED, event->time + event->thread->bursts.front()->length, event->thread);
        add_event(newEvent);
        running.pop();
    }
    else if(event->thread->bursts.empty()){
        return -1;
    }

    if(scheduler->size() > 0){
        active_thread = event->thread;
        Event* newEvent = new Event(Event::DISPATCHER_INVOKED, event->time, event->thread);
        add_event(newEvent);
    }
}


void Simulation::handle_io_burst_completed(const Event* event) {
    // TODO: handle this event properly (feel free to modify code structure, tho)
    event->thread->bursts.pop();
    event->thread->set_thread_state(Thread::State::READY, event->time, 0);
    scheduler->enqueue(event, event->thread);

    if(scheduler->size() == 1){
        Event* newEvent = new Event(Event::DISPATCHER_INVOKED, event->time, event->thread);
        add_event(newEvent);
    }
}


void Simulation::handle_thread_completed(const Event* event) {
    // TODO: handle this event properly (feel free to modify code structure, tho)
    running.pop();
    event->thread->set_thread_state(Thread::State::EXIT, event->time, 0);

    if(scheduler->size() > 0){
        Event* newEvent = new Event(Event::DISPATCHER_INVOKED, event->time, event->thread);
        add_event(newEvent);
    }
}


void Simulation::handle_thread_preempted(const Event* event) {
    running.pop();
    event->thread->set_thread_state(Thread::State::READY, event->time, 0);
    scheduler->enqueue(event, event->thread);

    Event* newEvent = new Event(Event::DISPATCHER_INVOKED, event->time, event->thread);
    add_event(newEvent);
}


void Simulation::handle_dispatcher_invoked(const Event* event) {
    // TODO: handle this event properly (feel free to modify code structure, tho)
    if(running.empty()){
        SchedulingDecision* schedDec = scheduler->get_next_thread(event);
        running.push(schedDec->thread);

        if(active_thread == nullptr){
            stats.dispatch_time = stats.dispatch_time + process_switch_overhead;
            Event* newEvent = new Event(Event::PROCESS_DISPATCH_COMPLETED, process_switch_overhead + event->time, s->thread);
            add_event(newEvent);
        }
        else if(schedDec->thread->process->pid != active_thread->process->pid){
            stats.dispatch_time = stats.dispatch_time + process_switch_overhead;
            Event* newEvent = new Event(Event::PROCESS_DISPATCH_COMPLETED, process_switch_overhead + event->time, s->thread);
            add_event(newEvent);
        }
        else{
            stats.dispatch_time = stats.dispatch_time + thread_switch_overhead;
            Event* newEvent = new Event(Event::THREAD_DISPATCH_COMPLETED, thread_switch_overhead + event->time, s->thread);
            add_event(newEvent);
        }

        logger.print_verbose(event, s->thread, s->explanation);
    }
    else if(!running.empty()){
        return -1;
    }
}


//==============================================================================
// Utility methods
//==============================================================================


void Simulation::add_event(Event* event) {
    if (event != nullptr) {
        events.push(event);
    }
}


void Simulation::read_file(const string& filename) {
    ifstream file(filename.c_str());

    if (!file.open()) {
        cerr << "Unable to open simulation file: " << filename << endl;
        exit(EXIT_FAILURE);
    }

    size_t num_processes;

    // Read the total number of processes, as well as the dispatch overheads.
    file >> num_processes >> thread_switch_overhead >> process_switch_overhead;

    // Read in each process.
    for (size_t p = 0; p < num_processes; ++p) {
        Process* process = read_process(file);

        processes[process->pid] = process;
    }
}


Process* Simulation::read_process(istream& in) {
    int pid;
    int type;
    size_t num_threads;

    // Read in the process ID, its type, and the number of threads.
    in >> pid >> type >> num_threads;

    // Create the process and register its existence in the processes map.
    Process* process = new Process(pid, (Process::Type) type);

    // Read in each thread in the process.
    for (size_t tid = 0; tid < num_threads; ++tid) {
        process->threads.push_back(read_thread(in, tid, process));
    }

    return process;
}


Thread* Simulation::read_thread(istream& in, int tid, Process* process) {
    int arrival_time;
    size_t num_cpu_bursts;

    // Read in the thread's arrival time and its number of CPU bursts.
    in >> arrival_time >> num_cpu_bursts;

    Thread* thread = new Thread(arrival_time, tid, process);

    // Read in each burst in the thread.
    for (size_t n = 0, burst_length; n < (num_cpu_bursts * 2) - 1; ++n) {
        in >> burst_length;

        Burst::Type burst_type = (n % 2 == 0)
                ? Burst::CPU
                : Burst::IO;

        thread->bursts.push(new Burst(burst_type, burst_length));
    }

    // Add an arrival event for the thread.
    events.push(new Event(Event::THREAD_ARRIVED, thread->arrival_time, thread));

    return thread;
}


SystemStats Simulation::calculate_statistics() {

    // get all the info for the threads and processes
    for(int i = 0; i < processes.size(); ++i){
        // current type of process
        Process::Type t = processes[i]->type;
        // iterate through all threads of that type
        for(int j = 0; j < processes[i]->threads.size(); ++j){
            stats.thread_counts[t] = stats.thread_counts[t] + 1.0;
            stats.service_time = stats.service_time + double(processes[i]->threads[j]->service_time);
            stats.io_time = stats.io_time + double(processes[i]->threads[j]->io_time);
            stats.avg_thread_response_times[t] = stats.avg_thread_response_times[t] + double(processes[i]->threads[j]->response_time());
            stats.avg_thread_turnaround_times[t] = stats.avg_thread_turnaround_times[t] + double(processes[i]->threads[j]->turnaround_time());
        }
    }

    // calculate CPU utilization and efficiency
    stats.total_idle_time = (stats.total_time - stats.dispatch_time - stats.service_time);
    stats.cpu_utilization = (1.0 - (double(stats.total_idle_time) / double(stats.total_time))) * 100.0;
    stats.cpu_efficiency = (1.0 - ((double(stats.total_idle_time) + double(stats.dispatch_time))/ double(stats.total_time))) * 100.0;

    // calculate average turnaround and response time for each type of thread
    for(int i = 0; i < 4; i++){
        stats.avg_thread_response_times[i] = stats.avg_thread_response_times[i] / stats.thread_counts[i];
        stats.avg_thread_turnaround_times[i] = stats.avg_thread_turnaround_times[i] / stats.thread_counts[i];
        if(isnan(stats.avg_thread_response_times[i])) stats.avg_thread_response_times[i] = 0.0;
        if(isnan(stats.avg_thread_turnaround_times[i])) stats.avg_thread_turnaround_times[i] = 0.0;
    }

    return stats;
}
